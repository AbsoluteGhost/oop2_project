from django.shortcuts import render
from django.http import HttpResponse
from .models import *
import smtplib
# Create your views here.


def index(request):
    return render(request, 'index.html')


def about(request):
    return render(request, 'about.html')


def services(request):
    return render(request, 'services.html')


def portfolio(request):
    portfolios = Portfolio.objects.all()
    return render(request, 'portfolio.html', {
        'portfolios': portfolios
    })


def portfolio_details(request, portfolio_id):
    # print(portfolio_id)
    portfolio_detail = Portfolio.objects.get(portfolio_id=portfolio_id)
    return render(request, 'portfolio-details.html', {
        'portfolio': portfolio_detail
    })


def subscribe(request):
    if request.method == "POST":
        # print(request)
        maillist = MailList()
        maillist.email = request.POST.get('email')
        maillist.save()

    return render(request, 'index.html')


def blog(request):
    return render(request, 'blog.html')


def design_gallery(request):
    return render(request, 'design_gallery.html')


def contact(request):
    if request.method == "POST":

        contact = Contact()
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        massage = request.POST.get('massage')

        contact.name = name
        contact.email = email
        contact.subject = subject
        contact.massage = massage
        contact.save()

        return HttpResponse(" Thank you for contacting us ")

    return render(request, 'contact.html')


def showdata(request):
    contacts = Contact.objects.all()
    data = {'Contact': contacts}
    return render(request, 'showdata.html', data)
