from django.apps import AppConfig


class InterioWebConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "interio_web"
